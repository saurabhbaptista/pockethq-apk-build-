package com.zapchicka.app.sync

import org.junit.Assert.assertEquals
import org.junit.Test

class SyncDecisionTest {
    @Test fun acceptedWhenServerReturnedUpdatedRow() {
        assertEquals(UpdateOutcome.ACCEPTED, SyncDecision.classifyUpdate(1, "m1", "other"))
    }

    @Test fun recognizesLostResponseRetry() {
        assertEquals(UpdateOutcome.IDEMPOTENT_RETRY, SyncDecision.classifyUpdate(0, "m1", "m1"))
    }

    @Test fun versionMismatchBecomesConflict() {
        assertEquals(UpdateOutcome.CONFLICT, SyncDecision.classifyUpdate(0, "m1", "m2"))
    }
}
