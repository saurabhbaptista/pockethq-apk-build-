package com.zapchicka.app

import android.app.Application
import androidx.room.Room
import androidx.work.*
import com.zapchicka.app.data.AppDatabase
import com.zapchicka.app.network.SupabaseApi
import com.zapchicka.app.repository.ZapChickaRepository
import com.zapchicka.app.security.SessionStore
import java.util.concurrent.TimeUnit

class ZapChickaApplication : Application() {
    lateinit var repository: ZapChickaRepository
        private set

    override fun onCreate() {
        super.onCreate()

        val db = Room.databaseBuilder(this, AppDatabase::class.java, "zapchicka.db")
            .fallbackToDestructiveMigration(false)
            .build()

        repository = ZapChickaRepository(
            db = db,
            api = SupabaseApi(BuildConfig.SUPABASE_URL, BuildConfig.SUPABASE_PUBLISHABLE_KEY),
            sessions = SessionStore(this)
        )

        val periodic = PeriodicWorkRequestBuilder<SyncWorker>(15, TimeUnit.MINUTES)
            .setConstraints(Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build())
            .build()

        WorkManager.getInstance(this).enqueueUniquePeriodicWork(
            "zapchicka_periodic_sync",
            ExistingPeriodicWorkPolicy.KEEP,
            periodic
        )
    }

    fun requestSync() {
        val request = OneTimeWorkRequestBuilder<SyncWorker>()
            .setConstraints(Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build())
            .build()
        WorkManager.getInstance(this).enqueueUniqueWork(
            "zapchicka_immediate_sync",
            ExistingWorkPolicy.REPLACE,
            request
        )
    }
}

class SyncWorker(
    context: android.content.Context,
    params: WorkerParameters
) : CoroutineWorker(context, params) {
    override suspend fun doWork(): Result {
        val app = applicationContext as ZapChickaApplication
        return try {
            if (app.repository.currentSession() == null) return Result.success()
            if (app.repository.currentWorkspace() == null) app.repository.restore()
            if (app.repository.currentWorkspace() == null) return Result.success()
            app.repository.syncNow()
            Result.success()
        } catch (_: Throwable) {
            Result.retry()
        }
    }
}
