package com.zapchicka.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.lifecycle.viewmodel.compose.viewModel
import com.zapchicka.app.ui.ZapChickaApp
import com.zapchicka.app.ui.ZapChickaTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            ZapChickaTheme {
                val vm: MainViewModel = viewModel()
                ZapChickaApp(vm)
            }
        }
    }
}
