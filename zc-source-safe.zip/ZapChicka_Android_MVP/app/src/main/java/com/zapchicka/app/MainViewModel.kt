package com.zapchicka.app

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.zapchicka.app.data.*
import com.zapchicka.app.network.WorkspaceContext
import com.zapchicka.app.repository.SyncState
import com.zapchicka.app.repository.ZapChickaRepository
import com.zapchicka.app.security.Session
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

data class AuthUiState(
    val restoring: Boolean = true,
    val session: Session? = null,
    val workspace: WorkspaceContext? = null,
    val message: String? = null,
    val busy: Boolean = false
)

class MainViewModel(app: Application) : AndroidViewModel(app) {
    private val application = app as ZapChickaApplication
    private val repo: ZapChickaRepository = application.repository

    private val _auth = MutableStateFlow(AuthUiState())
    val auth: StateFlow<AuthUiState> = _auth.asStateFlow()

    private val _workspaceId = MutableStateFlow<String?>(null)
    val suppliers = _workspaceId.filterNotNull().flatMapLatest(repo::suppliers)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())
    val products = _workspaceId.filterNotNull().flatMapLatest(repo::products)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())
    val tasks = _workspaceId.filterNotNull().flatMapLatest(repo::tasks)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())
    val activity = _workspaceId.filterNotNull().flatMapLatest(repo::activity)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())
    val conflicts = _workspaceId.filterNotNull().flatMapLatest(repo::conflicts)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())
    val pendingCount = _workspaceId.filterNotNull().flatMapLatest(repo::pendingCount)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), 0)

    init {
        viewModelScope.launch {
            val session = repo.restore()
            val ctx = repo.currentWorkspace()
            _workspaceId.value = ctx?.workspaceId
            _auth.value = AuthUiState(restoring=false, session=session, workspace=ctx)
            if (session != null && ctx != null) runCatching { repo.syncNow() }
        }
    }

    fun signIn(email: String, password: String) {
        viewModelScope.launch {
            _auth.value = _auth.value.copy(busy=true, message=null)
            repo.signIn(email, password)
                .onSuccess {
                    val ctx = repo.currentWorkspace()
                    _workspaceId.value = ctx?.workspaceId
                    _auth.value = AuthUiState(false, it, ctx, null, false)
                    if (ctx != null) runCatching { repo.syncNow() }
                }
                .onFailure { _auth.value = _auth.value.copy(busy=false, message=it.message ?: "Sign in failed") }
        }
    }

    fun signUp(name: String, email: String, password: String) {
        viewModelScope.launch {
            _auth.value = _auth.value.copy(busy=true, message=null)
            repo.signUp(email, password, name)
                .onSuccess {
                    val session = repo.currentSession()
                    val ctx = repo.currentWorkspace()
                    _workspaceId.value = ctx?.workspaceId
                    _auth.value = AuthUiState(false, session, ctx, it, false)
                }
                .onFailure { _auth.value = _auth.value.copy(busy=false, message=it.message ?: "Sign up failed") }
        }
    }

    fun acceptInvite(code: String) {
        viewModelScope.launch {
            _auth.value = _auth.value.copy(busy=true, message=null)
            repo.acceptInvite(code)
                .onSuccess {
                    _workspaceId.value = it.workspaceId
                    _auth.value = _auth.value.copy(workspace=it, busy=false, message="Workspace connected.")
                }
                .onFailure { _auth.value = _auth.value.copy(busy=false, message=it.message ?: "Invite failed") }
        }
    }

    fun signOut() {
        repo.signOut()
        _workspaceId.value = null
        _auth.value = AuthUiState(restoring=false)
    }

    fun sync() = viewModelScope.launch {
        runCatching { repo.syncNow() }
        _auth.value = _auth.value.copy(message = when (val s = repo.syncState) {
            is SyncState.Error -> s.message
            else -> _auth.value.message
        })
    }

    fun addSupplier(name: String, city: String?, category: String?, notes: String?) =
        viewModelScope.launch {
            repo.createSupplier(name, city, category, notes)
            application.requestSync()
        }

    fun updateSupplier(item: SupplierEntity) = viewModelScope.launch {
        repo.updateSupplier(item)
        application.requestSync()
    }

    fun addTask(title: String, details: String?, priority: String) = viewModelScope.launch {
        repo.createTask(title, details, priority)
        application.requestSync()
    }

    fun setTaskDone(item: TaskEntity, done: Boolean) = viewModelScope.launch {
        repo.setTaskDone(item, done)
        application.requestSync()
    }

    fun keepServer(conflict: LocalConflictEntity) = viewModelScope.launch {
        repo.resolveKeepServer(conflict)
    }

    fun retryMine(conflict: LocalConflictEntity) = viewModelScope.launch {
        repo.resolveRetryMine(conflict)
    }
}
