package com.zapchicka.app.ui

import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp

val ZcBg = Color(0xFF050708)
val ZcSurface = Color(0xFF0B1012)
val ZcRaised = Color(0xFF10181B)
val ZcNeon = Color(0xFFEDFF19)
val ZcChili = Color(0xFFFF4A26)
val ZcTeal = Color(0xFF42E8D1)
val ZcText = Color(0xFFF4F6F3)
val ZcMuted = Color(0xFF9BA4A6)
val ZcDanger = Color(0xFFE85555)

private val scheme = darkColorScheme(
    primary = ZcNeon,
    onPrimary = Color.Black,
    secondary = ZcTeal,
    tertiary = ZcChili,
    background = ZcBg,
    surface = ZcSurface,
    surfaceVariant = ZcRaised,
    onBackground = ZcText,
    onSurface = ZcText,
    onSurfaceVariant = ZcMuted,
    error = ZcDanger
)

@Composable
fun ZapChickaTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = scheme,
        shapes = Shapes(
            extraSmall = RoundedCornerShape(8.dp),
            small = RoundedCornerShape(12.dp),
            medium = RoundedCornerShape(18.dp),
            large = RoundedCornerShape(24.dp),
            extraLarge = RoundedCornerShape(32.dp)
        ),
        content = content
    )
}
