package com.zapchicka.app.data

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface SupplierDao {
    @Query("SELECT * FROM suppliers WHERE workspaceId=:workspaceId AND deletedAt IS NULL ORDER BY name COLLATE NOCASE")
    fun observe(workspaceId: String): Flow<List<SupplierEntity>>

    @Query("SELECT * FROM suppliers WHERE id=:id LIMIT 1")
    suspend fun get(id: String): SupplierEntity?

    @Upsert suspend fun upsert(item: SupplierEntity)
    @Upsert suspend fun upsertAll(items: List<SupplierEntity>)
}

@Dao
interface ProductDao {
    @Query("SELECT * FROM products WHERE workspaceId=:workspaceId AND deletedAt IS NULL ORDER BY code")
    fun observe(workspaceId: String): Flow<List<ProductEntity>>
    @Upsert suspend fun upsertAll(items: List<ProductEntity>)
}

@Dao
interface TaskDao {
    @Query("""
        SELECT * FROM tasks
        WHERE workspaceId=:workspaceId AND deletedAt IS NULL
        ORDER BY CASE priority WHEN 'critical' THEN 0 WHEN 'high' THEN 1 WHEN 'normal' THEN 2 ELSE 3 END,
                 CASE WHEN status='done' THEN 1 ELSE 0 END,
                 title COLLATE NOCASE
    """)
    fun observe(workspaceId: String): Flow<List<TaskEntity>>

    @Query("SELECT * FROM tasks WHERE id=:id LIMIT 1")
    suspend fun get(id: String): TaskEntity?

    @Upsert suspend fun upsert(item: TaskEntity)
    @Upsert suspend fun upsertAll(items: List<TaskEntity>)
}

@Dao
interface ActivityDao {
    @Query("SELECT * FROM activity_events WHERE workspaceId=:workspaceId ORDER BY id DESC LIMIT 100")
    fun observe(workspaceId: String): Flow<List<ActivityEventEntity>>
    @Upsert suspend fun upsertAll(items: List<ActivityEventEntity>)
}

@Dao
interface MutationDao {
    @Query("SELECT * FROM pending_mutations WHERE workspaceId=:workspaceId ORDER BY createdAtEpochMs LIMIT 50")
    suspend fun nextBatch(workspaceId: String): List<PendingMutationEntity>

    @Query("SELECT COUNT(*) FROM pending_mutations WHERE workspaceId=:workspaceId")
    fun observeCount(workspaceId: String): Flow<Int>

    @Query("""
        SELECT * FROM pending_mutations
        WHERE workspaceId=:workspaceId AND entityType=:entityType AND entityId=:entityId
        ORDER BY createdAtEpochMs DESC LIMIT 1
    """)
    suspend fun latestForEntity(workspaceId: String, entityType: String, entityId: String): PendingMutationEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun put(item: PendingMutationEntity)

    @Query("DELETE FROM pending_mutations WHERE id=:id")
    suspend fun delete(id: String)

    @Query("UPDATE pending_mutations SET attemptCount=attemptCount+1, lastError=:error WHERE id=:id")
    suspend fun markFailure(id: String, error: String)
}

@Dao
interface ConflictDao {
    @Query("SELECT * FROM sync_conflicts WHERE workspaceId=:workspaceId ORDER BY createdAtEpochMs DESC")
    fun observe(workspaceId: String): Flow<List<LocalConflictEntity>>

    @Query("SELECT * FROM sync_conflicts WHERE id=:id LIMIT 1")
    suspend fun get(id: String): LocalConflictEntity?

    @Upsert suspend fun upsert(item: LocalConflictEntity)

    @Query("DELETE FROM sync_conflicts WHERE serverConflictId IS NOT NULL")
    suspend fun deleteServerBacked()

    @Query("DELETE FROM sync_conflicts WHERE id=:id")
    suspend fun delete(id: String)
}

@Dao
interface SyncMetaDao {
    @Query("SELECT value FROM sync_meta WHERE key=:key LIMIT 1")
    suspend fun get(key: String): String?
    @Upsert suspend fun put(item: SyncMetaEntity)
}
