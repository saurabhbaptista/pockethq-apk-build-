package com.zapchicka.app.repository

import com.zapchicka.app.data.*
import com.zapchicka.app.network.SupabaseApi
import com.zapchicka.app.network.WorkspaceContext
import com.zapchicka.app.security.Session
import com.zapchicka.app.security.SessionStore
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.time.Instant
import java.util.UUID

sealed class SyncState {
    data object Idle : SyncState()
    data object Syncing : SyncState()
    data class Ok(val atEpochMs: Long) : SyncState()
    data class Error(val message: String) : SyncState()
}

class ZapChickaRepository(
    private val db: AppDatabase,
    private val api: SupabaseApi,
    private val sessions: SessionStore
) {
    @Volatile private var workspace: WorkspaceContext? = null
    private val syncMutex = Mutex()
    @Volatile var syncState: SyncState = SyncState.Idle
        private set

    fun currentSession(): Session? = sessions.load()
    fun currentWorkspace(): WorkspaceContext? = workspace

    suspend fun signIn(email: String, password: String): Result<Session> = withContext(Dispatchers.IO) {
        runCatching {
            val result = api.signIn(email.trim(), password)
            val session = result.session ?: error(result.message ?: "Sign in failed")
            sessions.save(session)
            workspace = api.getWorkspace(session.accessToken, session.userId)
            session
        }
    }

    suspend fun signUp(email: String, password: String, displayName: String): Result<String> =
        withContext(Dispatchers.IO) {
            runCatching {
                val result = api.signUp(email.trim(), password, displayName.trim())
                val session = result.session
                if (session == null) return@runCatching result.message ?: "Confirm your email, then sign in."
                sessions.save(session)
                workspace = api.getWorkspace(session.accessToken, session.userId)
                "Account created."
            }
        }

    suspend fun restore(): Session? = withContext(Dispatchers.IO) {
        var session = sessions.load() ?: return@withContext null
        if (session.expiresAtEpochSec < Instant.now().epochSecond + 120) {
            session = api.refresh(session.refreshToken, session.email) ?: run {
                sessions.clear()
                return@withContext null
            }
            sessions.save(session)
        }
        workspace = runCatching { api.getWorkspace(session.accessToken, session.userId) }.getOrNull()
        session
    }

    suspend fun acceptInvite(token: String): Result<WorkspaceContext> = withContext(Dispatchers.IO) {
        runCatching {
            val session = validSession() ?: error("Sign in first.")
            val ctx = api.acceptInvite(session.accessToken, token.trim())
            workspace = ctx
            syncNow()
            ctx
        }
    }

    fun signOut() {
        sessions.clear()
        workspace = null
    }

    fun suppliers(workspaceId: String): Flow<List<SupplierEntity>> = db.suppliers().observe(workspaceId)
    fun products(workspaceId: String): Flow<List<ProductEntity>> = db.products().observe(workspaceId)
    fun tasks(workspaceId: String): Flow<List<TaskEntity>> = db.tasks().observe(workspaceId)
    fun activity(workspaceId: String): Flow<List<ActivityEventEntity>> = db.activity().observe(workspaceId)
    fun conflicts(workspaceId: String): Flow<List<LocalConflictEntity>> = db.conflicts().observe(workspaceId)
    fun pendingCount(workspaceId: String): Flow<Int> = db.mutations().observeCount(workspaceId)

    suspend fun createSupplier(name: String, city: String?, category: String?, notes: String?) {
        val ctx = workspace ?: error("No workspace.")
        val id = UUID.randomUUID().toString()
        val mutationId = UUID.randomUUID().toString()
        val local = SupplierEntity(
            id=id, workspaceId=ctx.workspaceId, name=name.trim(), city=city?.trim()?.ifBlank { null },
            country="Thailand", category=category?.trim()?.ifBlank { null }, stage="research",
            notes=notes?.trim()?.ifBlank { null }, nextFollowUpAt=null,
            version=1, lastMutationId=mutationId, updatedAt=Instant.now().toString(),
            deletedAt=null, pending=true
        )
        db.suppliers().upsert(local)
        val payload = supplierPayload(local)
        enqueue(ctx.workspaceId, "suppliers", id, "insert", null, payload, mutationId)
    }

    suspend fun updateSupplier(item: SupplierEntity) {
        val ctx = workspace ?: error("No workspace.")
        check(!item.conflict) { "Resolve this supplier conflict before editing again." }
        val existing = db.mutations().latestForEntity(ctx.workspaceId, "suppliers", item.id)
        val mutationId = existing?.id ?: UUID.randomUUID().toString()
        val updated = item.copy(lastMutationId=mutationId, pending=true, conflict=false)
        db.suppliers().upsert(updated)
        queueLatestEntityState(
            ctx.workspaceId, "suppliers", item.id, item.version,
            supplierPayload(updated), mutationId, existing
        )
    }

    suspend fun createTask(title: String, details: String?, priority: String) {
        val ctx = workspace ?: error("No workspace.")
        val id = UUID.randomUUID().toString()
        val mutationId = UUID.randomUUID().toString()
        val local = TaskEntity(
            id=id, workspaceId=ctx.workspaceId, title=title.trim(),
            details=details?.trim()?.ifBlank { null }, status="open", priority=priority,
            dueAt=null, assignedTo=null, supplierId=null, productId=null, completedAt=null,
            version=1, lastMutationId=mutationId, updatedAt=Instant.now().toString(),
            deletedAt=null, pending=true
        )
        db.tasks().upsert(local)
        enqueue(ctx.workspaceId, "tasks", id, "insert", null, taskPayload(local), mutationId)
    }

    suspend fun setTaskDone(item: TaskEntity, done: Boolean) {
        val ctx = workspace ?: error("No workspace.")
        check(!item.conflict) { "Resolve this task conflict before editing again." }
        val existing = db.mutations().latestForEntity(ctx.workspaceId, "tasks", item.id)
        val mutationId = existing?.id ?: UUID.randomUUID().toString()
        val updated = item.copy(
            status = if (done) "done" else "open",
            completedAt = if (done) Instant.now().toString() else null,
            lastMutationId=mutationId, pending=true, conflict=false
        )
        db.tasks().upsert(updated)
        queueLatestEntityState(
            ctx.workspaceId, "tasks", item.id, item.version,
            taskPayload(updated), mutationId, existing
        )
    }

    private suspend fun enqueue(
        workspaceId: String, type: String, entityId: String, operation: String,
        baseVersion: Long?, payload: JSONObject, mutationId: String
    ) {
        db.mutations().put(
            PendingMutationEntity(
                id=mutationId, workspaceId=workspaceId, entityType=type, entityId=entityId,
                operation=operation, baseVersion=baseVersion, payloadJson=payload.toString(),
                createdAtEpochMs=System.currentTimeMillis()
            )
        )
    }

    private suspend fun queueLatestEntityState(
        workspaceId: String, type: String, entityId: String, baseVersion: Long,
        payload: JSONObject, mutationId: String, existing: PendingMutationEntity?
    ) {
        if (existing == null) {
            enqueue(workspaceId, type, entityId, "update", baseVersion, payload, mutationId)
            return
        }

        // Repeated offline edits to one record collapse into the latest local state.
        // If the entity itself was created offline, keep the original INSERT mutation.
        val effectivePayload = JSONObject(payload.toString()).put("last_mutation_id", existing.id)
        db.mutations().put(
            existing.copy(
                payloadJson = effectivePayload.toString(),
                attemptCount = 0,
                lastError = null
            )
        )
    }

    suspend fun syncNow() = syncMutex.withLock {
        withContext(Dispatchers.IO) {
            val ctx = workspace ?: return@withContext
            val session = validSession() ?: return@withContext
            syncState = SyncState.Syncing
            try {
                pushPending(session, ctx)
                pullAll(session, ctx)
                db.syncMeta().put(SyncMetaEntity("last_sync", System.currentTimeMillis().toString()))
                syncState = SyncState.Ok(System.currentTimeMillis())
            } catch (t: Throwable) {
                syncState = SyncState.Error(t.message ?: "Sync failed")
                throw t
            }
        }
    }

    private suspend fun validSession(): Session? {
        var s = sessions.load() ?: return null
        if (s.expiresAtEpochSec < Instant.now().epochSecond + 120) {
            s = api.refresh(s.refreshToken, s.email) ?: run {
                sessions.clear()
                return null
            }
            sessions.save(s)
        }
        return s
    }

    private suspend fun pushPending(session: Session, ctx: WorkspaceContext) {
        for (m in db.mutations().nextBatch(ctx.workspaceId)) {
            try {
                val payload = JSONObject(m.payloadJson)
                if (m.operation == "insert") {
                    val r = api.insert(session.accessToken, m.entityType, payload)
                    if (r.isSuccessful) {
                        val arr = JSONArray(r.body)
                        if (arr.length() > 0) applyServerObject(m.entityType, arr.getJSONObject(0))
                        db.mutations().delete(m.id)
                    } else if (r.code == 409) {
                        val server = api.getById(session.accessToken, m.entityType, m.entityId)
                        if (server?.optString("last_mutation_id") == m.id) {
                            applyServerObject(m.entityType, server)
                            db.mutations().delete(m.id)
                        } else {
                            throw IllegalStateException("Insert conflict")
                        }
                    } else {
                        throw IllegalStateException("Insert failed (${r.code})")
                    }
                } else {
                    val base = m.baseVersion ?: error("Missing base version")
                    val r = api.updateVersioned(session.accessToken, m.entityType, m.entityId, base, payload)
                    if (!r.isSuccessful) throw IllegalStateException("Update failed (${r.code})")

                    val arr = JSONArray(r.body)
                    if (arr.length() > 0) {
                        applyServerObject(m.entityType, arr.getJSONObject(0))
                        db.mutations().delete(m.id)
                    } else {
                        val server = api.getById(session.accessToken, m.entityType, m.entityId)
                            ?: throw IllegalStateException("Server row no longer exists")
                        if (server.optString("last_mutation_id") == m.id) {
                            applyServerObject(m.entityType, server)
                            db.mutations().delete(m.id)
                        } else {
                            recordConflict(session, ctx, m, server)
                            db.mutations().delete(m.id)
                        }
                    }
                }
            } catch (t: Throwable) {
                db.mutations().markFailure(m.id, t.message ?: "sync error")
                throw t
            }
        }
    }

    private suspend fun recordConflict(
        session: Session,
        ctx: WorkspaceContext,
        m: PendingMutationEntity,
        server: JSONObject
    ) {
        val localId = UUID.randomUUID().toString()
        val serverVersion = server.getLong("version")
        val serverConflict = api.createConflict(
            session.accessToken,
            JSONObject()
                .put("workspace_id", ctx.workspaceId)
                .put("entity_type", m.entityType)
                .put("entity_id", m.entityId)
                .put("base_version", m.baseVersion)
                .put("server_version", serverVersion)
                .put("local_payload", JSONObject(m.payloadJson))
                .put("server_payload", server)
                .put("raised_by", session.userId)
        )
        db.conflicts().upsert(
            LocalConflictEntity(
                id=localId,
                serverConflictId=serverConflict?.optString("id")?.takeIf { it.isNotBlank() },
                workspaceId=ctx.workspaceId,
                entityType=m.entityType,
                entityId=m.entityId,
                baseVersion=m.baseVersion ?: 0,
                serverVersion=serverVersion,
                localPayloadJson=m.payloadJson,
                serverPayloadJson=server.toString(),
                createdAtEpochMs=System.currentTimeMillis()
            )
        )
        when (m.entityType) {
            "suppliers" -> db.suppliers().get(m.entityId)?.let { db.suppliers().upsert(it.copy(conflict=true, pending=false)) }
            "tasks" -> db.tasks().get(m.entityId)?.let { db.tasks().upsert(it.copy(conflict=true, pending=false)) }
        }
    }

    suspend fun resolveKeepServer(conflict: LocalConflictEntity) = withContext(Dispatchers.IO) {
        val session = validSession() ?: error("Not signed in")
        val server = JSONObject(conflict.serverPayloadJson)
        applyServerObject(conflict.entityType, server)
        val serverResolved = conflict.serverConflictId?.let {
            api.resolveConflict(
                session.accessToken, it,
                JSONObject()
                    .put("resolved_at", Instant.now().toString())
                    .put("resolved_by", session.userId)
                    .put("resolution", "server")
            )
        } ?: true
        check(serverResolved) { "Server conflict resolution was not acknowledged." }
        db.conflicts().delete(conflict.id)
    }

    suspend fun resolveRetryMine(conflict: LocalConflictEntity) = withContext(Dispatchers.IO) {
        val session = validSession() ?: error("Not signed in")
        val mutationId = UUID.randomUUID().toString()
        val payload = JSONObject(conflict.localPayloadJson).put("last_mutation_id", mutationId)
        enqueue(
            conflict.workspaceId, conflict.entityType, conflict.entityId, "update",
            conflict.serverVersion, payload, mutationId
        )

        // Do not mark the conflict resolved remotely until the retry has actually synchronized.
        syncNow()
        val serverResolved = conflict.serverConflictId?.let {
            api.resolveConflict(
                session.accessToken, it,
                JSONObject()
                    .put("resolved_at", Instant.now().toString())
                    .put("resolved_by", session.userId)
                    .put("resolution", "local_retry_applied")
            )
        } ?: true
        check(serverResolved) { "Retried edit synced, but conflict acknowledgement failed." }
        db.conflicts().delete(conflict.id)
    }

    private suspend fun pullAll(session: Session, ctx: WorkspaceContext) {
        parseSuppliers(api.list(session.accessToken, "suppliers", ctx.workspaceId, "name.asc"))
        parseProducts(api.list(session.accessToken, "products", ctx.workspaceId, "code.asc"))
        parseTasks(api.list(session.accessToken, "tasks", ctx.workspaceId, "updated_at.desc"))
        parseConflicts(api.listOpenConflicts(session.accessToken, ctx.workspaceId))
        parseActivity(api.list(session.accessToken, "activity_events", ctx.workspaceId, "id.desc"))
    }

    private suspend fun parseSuppliers(a: JSONArray) {
        for (i in 0 until a.length()) {
            val incoming = supplierFrom(a.getJSONObject(i))
            val local = db.suppliers().get(incoming.id)
            if (local?.pending == true) continue
            db.suppliers().upsert(incoming)
        }
    }

    private suspend fun parseProducts(a: JSONArray) {
        val items = buildList {
            for (i in 0 until a.length()) {
                val o = a.getJSONObject(i)
                add(ProductEntity(
                    id=o.getString("id"), workspaceId=o.getString("workspace_id"),
                    code=o.getString("code"), name=o.getString("name"), flavor=o.getString("flavor"),
                    packGrams=o.optIntOrNull("pack_grams"), stage=o.optNullable("stage"),
                    targetRetailAed=o.optDoubleOrNull("target_retail_aed"), notes=o.optNullable("notes"),
                    version=o.getLong("version"), lastMutationId=o.getString("last_mutation_id"),
                    updatedAt=o.optNullable("updated_at"), deletedAt=o.optNullable("deleted_at")
                ))
            }
        }
        db.products().upsertAll(items)
    }

    private suspend fun parseTasks(a: JSONArray) {
        for (i in 0 until a.length()) {
            val incoming = taskFrom(a.getJSONObject(i))
            val local = db.tasks().get(incoming.id)
            if (local?.pending == true) continue
            db.tasks().upsert(incoming)
        }
    }

    private suspend fun parseConflicts(a: JSONArray) {
        // Server-backed conflicts are authoritative across devices. Preserve any local-only
        // fallback conflict whose server insert failed, and refresh all server-backed rows.
        db.conflicts().deleteServerBacked()
        for (i in 0 until a.length()) {
            val o = a.getJSONObject(i)
            val id = o.getString("id")
            val raisedAt = o.optNullable("raised_at")
            val raisedEpoch = raisedAt?.let {
                runCatching { Instant.parse(it).toEpochMilli() }.getOrDefault(System.currentTimeMillis())
            } ?: System.currentTimeMillis()
            db.conflicts().upsert(
                LocalConflictEntity(
                    id = id,
                    serverConflictId = id,
                    workspaceId = o.getString("workspace_id"),
                    entityType = o.getString("entity_type"),
                    entityId = o.getString("entity_id"),
                    baseVersion = o.getLong("base_version"),
                    serverVersion = o.getLong("server_version"),
                    localPayloadJson = o.getJSONObject("local_payload").toString(),
                    serverPayloadJson = o.getJSONObject("server_payload").toString(),
                    createdAtEpochMs = raisedEpoch
                )
            )
            when (o.getString("entity_type")) {
                "suppliers" -> db.suppliers().get(o.getString("entity_id"))?.let {
                    db.suppliers().upsert(it.copy(conflict = true, pending = false))
                }
                "tasks" -> db.tasks().get(o.getString("entity_id"))?.let {
                    db.tasks().upsert(it.copy(conflict = true, pending = false))
                }
            }
        }
    }

    private suspend fun parseActivity(a: JSONArray) {
        val items = buildList {
            for (i in 0 until a.length()) {
                val o = a.getJSONObject(i)
                add(ActivityEventEntity(
                    id=o.getLong("id"), workspaceId=o.getString("workspace_id"),
                    entityType=o.getString("entity_type"), entityId=o.optNullable("entity_id"),
                    action=o.getString("action"), actorId=o.optNullable("actor_id"),
                    occurredAt=o.getString("occurred_at"),
                    oldVersion=o.optLongOrNull("old_version"), newVersion=o.optLongOrNull("new_version"),
                    mutationId=o.optNullable("mutation_id")
                ))
            }
        }
        db.activity().upsertAll(items)
    }

    private suspend fun applyServerObject(type: String, o: JSONObject) {
        when (type) {
            "suppliers" -> db.suppliers().upsert(supplierFrom(o))
            "tasks" -> db.tasks().upsert(taskFrom(o))
        }
    }

    private fun supplierFrom(o: JSONObject) = SupplierEntity(
        id=o.getString("id"), workspaceId=o.getString("workspace_id"),
        name=o.getString("name"), city=o.optNullable("city"), country=o.optNullable("country"),
        category=o.optNullable("category"), stage=o.optNullable("stage"), notes=o.optNullable("notes"),
        nextFollowUpAt=o.optNullable("next_follow_up_at"), version=o.getLong("version"),
        lastMutationId=o.getString("last_mutation_id"), updatedAt=o.optNullable("updated_at"),
        deletedAt=o.optNullable("deleted_at"), pending=false, conflict=false
    )

    private fun taskFrom(o: JSONObject) = TaskEntity(
        id=o.getString("id"), workspaceId=o.getString("workspace_id"),
        title=o.getString("title"), details=o.optNullable("details"), status=o.getString("status"),
        priority=o.getString("priority"), dueAt=o.optNullable("due_at"),
        assignedTo=o.optNullable("assigned_to"), supplierId=o.optNullable("supplier_id"),
        productId=o.optNullable("product_id"), completedAt=o.optNullable("completed_at"),
        version=o.getLong("version"), lastMutationId=o.getString("last_mutation_id"),
        updatedAt=o.optNullable("updated_at"), deletedAt=o.optNullable("deleted_at"),
        pending=false, conflict=false
    )

    private fun supplierPayload(s: SupplierEntity) = JSONObject()
        .put("id", s.id).put("workspace_id", s.workspaceId).put("name", s.name)
        .putNullable("city", s.city).putNullable("country", s.country)
        .putNullable("category", s.category).putNullable("stage", s.stage)
        .putNullable("notes", s.notes).putNullable("next_follow_up_at", s.nextFollowUpAt)
        .put("last_mutation_id", s.lastMutationId)

    private fun taskPayload(t: TaskEntity) = JSONObject()
        .put("id", t.id).put("workspace_id", t.workspaceId).put("title", t.title)
        .putNullable("details", t.details).put("status", t.status).put("priority", t.priority)
        .putNullable("due_at", t.dueAt).putNullable("assigned_to", t.assignedTo)
        .putNullable("supplier_id", t.supplierId).putNullable("product_id", t.productId)
        .putNullable("completed_at", t.completedAt).put("last_mutation_id", t.lastMutationId)
}

private fun JSONObject.optNullable(name: String): String? =
    if (!has(name) || isNull(name)) null else optString(name).takeIf { it.isNotBlank() && it != "null" }

private fun JSONObject.optIntOrNull(name: String): Int? =
    if (!has(name) || isNull(name)) null else getInt(name)

private fun JSONObject.optDoubleOrNull(name: String): Double? =
    if (!has(name) || isNull(name)) null else getDouble(name)

private fun JSONObject.optLongOrNull(name: String): Long? =
    if (!has(name) || isNull(name)) null else getLong(name)

private fun JSONObject.putNullable(name: String, value: Any?): JSONObject {
    if (value == null) put(name, JSONObject.NULL) else put(name, value)
    return this
}
