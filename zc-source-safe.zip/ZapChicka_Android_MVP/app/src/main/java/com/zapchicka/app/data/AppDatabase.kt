package com.zapchicka.app.data

import androidx.room.Database
import androidx.room.RoomDatabase

@Database(
    entities = [
        SupplierEntity::class,
        ProductEntity::class,
        TaskEntity::class,
        ActivityEventEntity::class,
        PendingMutationEntity::class,
        LocalConflictEntity::class,
        SyncMetaEntity::class
    ],
    version = 1,
    exportSchema = true
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun suppliers(): SupplierDao
    abstract fun products(): ProductDao
    abstract fun tasks(): TaskDao
    abstract fun activity(): ActivityDao
    abstract fun mutations(): MutationDao
    abstract fun conflicts(): ConflictDao
    abstract fun syncMeta(): SyncMetaDao
}
