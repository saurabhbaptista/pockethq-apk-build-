package com.zapchicka.app.ui

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.*
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.*
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.zapchicka.app.MainViewModel
import com.zapchicka.app.R
import com.zapchicka.app.data.*
import kotlinx.coroutines.delay
import java.time.LocalTime

private enum class Section(val label: String) {
    COMMAND("Command"), SUPPLIERS("Suppliers"), PRODUCTS("Products"), WORK("Work"), MORE("More")
}

@Composable
fun ZapChickaApp(vm: MainViewModel) {
    val auth by vm.auth.collectAsState()
    val suppliers by vm.suppliers.collectAsState()
    val products by vm.products.collectAsState()
    val tasks by vm.tasks.collectAsState()
    val activity by vm.activity.collectAsState()
    val conflicts by vm.conflicts.collectAsState()
    val pending by vm.pendingCount.collectAsState()

    if (auth.restoring) {
        Box(Modifier.fillMaxSize().background(ZcBg), contentAlignment = Alignment.Center) {
            CircularProgressIndicator(color = ZcNeon)
        }
        return
    }

    if (auth.session == null) {
        AuthScreen(auth.message, auth.busy, vm::signIn, vm::signUp)
        return
    }

    if (auth.workspace == null) {
        InviteScreen(auth.message, auth.busy, vm::acceptInvite, vm::signOut)
        return
    }

    // Automatic foreground pull while connected/open. WorkManager covers background retries.
    LaunchedEffect(auth.workspace!!.workspaceId) {
        while (true) {
            vm.sync()
            delay(20_000)
        }
    }

    var section by rememberSaveable { mutableStateOf(Section.COMMAND) }

    Scaffold(
        containerColor = ZcBg,
        bottomBar = {
            NavigationBar(containerColor = Color(0xFF070B0D)) {
                Section.entries.forEach { s ->
                    val icon = when (s) {
                        Section.COMMAND -> Icons.Default.Home
                        Section.SUPPLIERS -> Icons.Default.Groups
                        Section.PRODUCTS -> Icons.Default.Inventory2
                        Section.WORK -> Icons.Default.Checklist
                        Section.MORE -> Icons.Default.MoreHoriz
                    }
                    NavigationBarItem(
                        selected = section == s,
                        onClick = { section = s },
                        icon = { Icon(icon, null) },
                        label = { Text(s.label, fontSize = 10.sp) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = Color.Black,
                            selectedTextColor = ZcNeon,
                            indicatorColor = ZcNeon,
                            unselectedIconColor = ZcMuted,
                            unselectedTextColor = ZcMuted
                        )
                    )
                }
            }
        }
    ) { padding ->
        Box(Modifier.padding(padding).fillMaxSize()) {
            when (section) {
                Section.COMMAND -> CommandScreen(
                    homeMode = auth.workspace!!.homeMode,
                    suppliers = suppliers,
                    products = products,
                    tasks = tasks,
                    conflicts = conflicts,
                    pending = pending,
                    onSync = vm::sync
                )
                Section.SUPPLIERS -> SuppliersScreen(suppliers, vm::addSupplier, vm::updateSupplier)
                Section.PRODUCTS -> ProductsScreen(products)
                Section.WORK -> WorkScreen(tasks, vm::addTask, vm::setTaskDone)
                Section.MORE -> MoreScreen(activity, conflicts, pending, auth.workspace!!.role, vm::keepServer, vm::retryMine, vm::signOut)
            }
        }
    }
}

@Composable
private fun TopIdentity(title: String, subtitle: String? = null, onSync: (() -> Unit)? = null) {
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            Modifier.size(40.dp).clip(RoundedCornerShape(12.dp))
                .background(Color.Black)
                .border(1.dp, ZcNeon.copy(alpha=.7f), RoundedCornerShape(12.dp)),
            contentAlignment = Alignment.Center
        ) { Text("ZC", color=ZcNeon, fontWeight=FontWeight.Black, fontStyle=FontStyle.Italic) }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(title, fontWeight=FontWeight.Bold, fontSize=20.sp)
            subtitle?.let { Text(it, color=ZcMuted, fontSize=12.sp) }
        }
        onSync?.let {
            IconButton(onClick=it) { Icon(Icons.Default.Sync, "Sync", tint=ZcTeal) }
        }
    }
}

@Composable
private fun CommandScreen(
    homeMode: String,
    suppliers: List<SupplierEntity>,
    products: List<ProductEntity>,
    tasks: List<TaskEntity>,
    conflicts: List<LocalConflictEntity>,
    pending: Int,
    onSync: () -> Unit
) {
    if (homeMode == "founder") {
        FounderCommand(suppliers, products, tasks, conflicts, pending, onSync)
    } else {
        ControlCenter(suppliers, products, tasks, conflicts, pending, onSync)
    }
}

@Composable
private fun FounderCommand(
    suppliers: List<SupplierEntity>,
    products: List<ProductEntity>,
    tasks: List<TaskEntity>,
    conflicts: List<LocalConflictEntity>,
    pending: Int,
    onSync: () -> Unit
) {
    val hour = LocalTime.now().hour
    val greeting = when (hour) {
        in 5..11 -> "Good morning"
        in 12..17 -> "Good afternoon"
        else -> "Good evening"
    }
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom=20.dp)) {
        item { TopIdentity("ZapChicka", "Founder Command", onSync) }
        item {
            Box(
                Modifier.padding(horizontal=16.dp).fillMaxWidth().height(350.dp)
                    .clip(RoundedCornerShape(28.dp))
            ) {
                Image(
                    painterResource(R.drawable.may_founder),
                    contentDescription = "May with ZapChicka pouch",
                    modifier = Modifier.fillMaxSize(),
                    contentScale = ContentScale.Crop
                )
                Box(
                    Modifier.fillMaxSize().background(
                        Brush.verticalGradient(
                            0f to Color.Black.copy(alpha=.05f),
                            .55f to Color.Transparent,
                            1f to Color.Black.copy(alpha=.92f)
                        )
                    )
                )
                Column(
                    Modifier.align(Alignment.BottomStart).padding(22.dp)
                ) {
                    Text("$greeting,", color=Color.White, fontSize=19.sp)
                    Text("May.", color=ZcNeon, fontWeight=FontWeight.Black, fontSize=42.sp)
                    Text("From Thailand to the world.", color=Color.White, fontSize=16.sp)
                }
            }
        }
        item { StatsRow(suppliers.size, products.size, tasks.count { it.status != "done" }, conflicts.size) }
        item { SectionTitle("Today’s priorities") }
        val open = tasks.filter { it.status != "done" }.take(5)
        if (open.isEmpty()) item { EmptyCard("No open work recorded yet.") }
        items(open, key={it.id}) { TaskMini(it) }
        if (pending > 0) item {
            InfoCard("$pending change${if (pending==1) "" else "s"} waiting to sync.", Icons.Default.CloudUpload, ZcTeal)
        }
    }
}

@Composable
private fun ControlCenter(
    suppliers: List<SupplierEntity>,
    products: List<ProductEntity>,
    tasks: List<TaskEntity>,
    conflicts: List<LocalConflictEntity>,
    pending: Int,
    onSync: () -> Unit
) {
    val open = tasks.count { it.status != "done" }
    LazyColumn(Modifier.fillMaxSize(), contentPadding=PaddingValues(bottom=20.dp)) {
        item { TopIdentity("Intelligent Control Center", "Operational oversight", onSync) }
        item {
            Card(
                Modifier.padding(horizontal=16.dp).fillMaxWidth(),
                colors=CardDefaults.cardColors(containerColor=ZcSurface),
                border=BorderStroke(1.dp, ZcTeal.copy(alpha=.28f))
            ) {
                Row(Modifier.padding(18.dp), verticalAlignment=Alignment.CenterVertically) {
                    Box(Modifier.size(10.dp).clip(CircleShape).background(ZcTeal))
                    Spacer(Modifier.width(10.dp))
                    Column(Modifier.weight(1f)) {
                        Text("Shared workspace enabled", fontWeight=FontWeight.Bold)
                        Text("Automatic sync is configured for both owners.", color=ZcMuted, fontSize=12.sp)
                    }
                    Text("AUTO SYNC", color=ZcTeal, fontWeight=FontWeight.Bold, fontSize=11.sp)
                }
            }
        }
        item { StatsRow(suppliers.size, products.size, open, conflicts.size) }
        item { SectionTitle("Action required") }
        if (conflicts.isNotEmpty()) item {
            InfoCard("${conflicts.size} edit conflict${if(conflicts.size==1)"" else "s"} require an explicit decision.", Icons.Default.Warning, ZcDanger)
        }
        if (pending > 0) item {
            InfoCard("$pending local change${if(pending==1)"" else "s"} not yet acknowledged by the server.", Icons.Default.CloudUpload, ZcTeal)
        }
        if (open > 0) item {
            InfoCard("$open open work item${if(open==1)"" else "s"}.", Icons.Default.Checklist, ZcNeon)
        }
        if (conflicts.isEmpty() && pending == 0 && open == 0) item {
            EmptyCard("No deterministic exceptions detected in the current MVP scope.")
        }
        item { SectionTitle("Business overview") }
        item {
            Text(
                "Commercial, regulatory and certification modules remain deliberately unfilled until verified records are entered.",
                color=ZcMuted, fontSize=13.sp,
                modifier=Modifier.padding(horizontal=20.dp)
            )
        }
    }
}

@Composable
private fun StatsRow(suppliers:Int, products:Int, open:Int, conflicts:Int) {
    Row(
        Modifier.fillMaxWidth().padding(16.dp),
        horizontalArrangement=Arrangement.spacedBy(8.dp)
    ) {
        MiniStat("Suppliers", suppliers.toString(), Icons.Default.Groups, Modifier.weight(1f))
        MiniStat("Products", products.toString(), Icons.Default.Inventory2, Modifier.weight(1f))
        MiniStat("Open", open.toString(), Icons.Default.Checklist, Modifier.weight(1f))
        MiniStat("Conflicts", conflicts.toString(), Icons.Default.Warning, Modifier.weight(1f))
    }
}

@Composable
private fun MiniStat(label:String, value:String, icon: androidx.compose.ui.graphics.vector.ImageVector, modifier:Modifier=Modifier) {
    Card(modifier, colors=CardDefaults.cardColors(containerColor=ZcSurface)) {
        Column(Modifier.padding(12.dp)) {
            Icon(icon, null, tint=ZcNeon, modifier=Modifier.size(18.dp))
            Spacer(Modifier.height(8.dp))
            Text(value, fontWeight=FontWeight.Black, fontSize=22.sp)
            Text(label, color=ZcMuted, fontSize=10.sp, maxLines=1)
        }
    }
}

@Composable
private fun SuppliersScreen(
    suppliers: List<SupplierEntity>,
    add: (String,String?,String?,String?)->Unit,
    update: (SupplierEntity)->Unit
) {
    var adding by remember { mutableStateOf(false) }
    var editing by remember { mutableStateOf<SupplierEntity?>(null) }
    Column(Modifier.fillMaxSize()) {
        TopIdentity("Suppliers", "Verified records only")
        Row(Modifier.fillMaxWidth().padding(horizontal=16.dp), horizontalArrangement=Arrangement.End) {
            Button(onClick={adding=true}, colors=ButtonDefaults.buttonColors(containerColor=ZcNeon, contentColor=Color.Black)) {
                Icon(Icons.Default.Add, null); Spacer(Modifier.width(6.dp)); Text("Add supplier")
            }
        }
        if (suppliers.isEmpty()) {
            Box(Modifier.fillMaxSize(), contentAlignment=Alignment.Center) {
                Text("No suppliers recorded yet.", color=ZcMuted)
            }
        } else {
            LazyColumn(contentPadding=PaddingValues(16.dp), verticalArrangement=Arrangement.spacedBy(10.dp)) {
                items(suppliers, key={it.id}) { s ->
                    Card(
                        Modifier.fillMaxWidth().clickable(enabled = !s.conflict) { editing=s },
                        colors=CardDefaults.cardColors(containerColor=ZcSurface)
                    ) {
                        Row(Modifier.padding(16.dp), verticalAlignment=Alignment.CenterVertically) {
                            Box(Modifier.size(44.dp).clip(RoundedCornerShape(12.dp)).background(ZcRaised), contentAlignment=Alignment.Center) {
                                Text(s.name.take(2).uppercase(), color=ZcNeon, fontWeight=FontWeight.Bold)
                            }
                            Spacer(Modifier.width(12.dp))
                            Column(Modifier.weight(1f)) {
                                Text(s.name, fontWeight=FontWeight.Bold)
                                Text(listOfNotNull(s.city,s.country).joinToString(", ").ifBlank {"Location not recorded"}, color=ZcMuted, fontSize=12.sp)
                                s.category?.let { Text(it, color=ZcMuted, fontSize=11.sp) }
                            }
                            if (s.pending) Icon(Icons.Default.CloudUpload, "Pending", tint=ZcTeal)
                            if (s.conflict) Icon(Icons.Default.Warning, "Conflict", tint=ZcDanger)
                        }
                    }
                }
            }
        }
    }
    if (adding) SupplierDialog(null, onDismiss={adding=false}) { n,c,cat,notes ->
        add(n,c,cat,notes); adding=false
    }
    editing?.let { item ->
        SupplierDialog(item, onDismiss={editing=null}) { n,c,cat,notes ->
            update(item.copy(name=n, city=c, category=cat, notes=notes)); editing=null
        }
    }
}

@Composable
private fun SupplierDialog(item: SupplierEntity?, onDismiss:()->Unit, onSave:(String,String?,String?,String?)->Unit) {
    var name by remember(item) { mutableStateOf(item?.name ?: "") }
    var city by remember(item) { mutableStateOf(item?.city ?: "") }
    var category by remember(item) { mutableStateOf(item?.category ?: "") }
    var notes by remember(item) { mutableStateOf(item?.notes ?: "") }
    AlertDialog(
        onDismissRequest=onDismiss,
        title={Text(if(item==null) "Add supplier" else "Edit supplier")},
        text={
            Column(verticalArrangement=Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(name,{name=it},label={Text("Supplier name")},singleLine=true)
                OutlinedTextField(city,{city=it},label={Text("City")},singleLine=true)
                OutlinedTextField(category,{category=it},label={Text("Category")},singleLine=true)
                OutlinedTextField(notes,{notes=it},label={Text("Notes")},minLines=3)
            }
        },
        confirmButton={
            TextButton(enabled=name.isNotBlank(),onClick={onSave(name,city.ifBlank{null},category.ifBlank{null},notes.ifBlank{null})}) { Text("Save") }
        },
        dismissButton={TextButton(onClick=onDismiss){Text("Cancel")}}
    )
}

@Composable
private fun ProductsScreen(products: List<ProductEntity>) {
    LazyColumn(Modifier.fillMaxSize(), contentPadding=PaddingValues(bottom=20.dp)) {
        item { TopIdentity("Products & Development", "From concept to launch") }
        if (products.isEmpty()) item { EmptyCard("No product records available.") }
        items(products, key={it.id}) { p ->
            val chili = p.code.contains("CHILI")
            val accent = if(chili) ZcChili else ZcNeon
            Card(
                Modifier.padding(horizontal=16.dp, vertical=7.dp).fillMaxWidth(),
                colors=CardDefaults.cardColors(containerColor=ZcSurface)
            ) {
                Row(Modifier.padding(16.dp), verticalAlignment=Alignment.CenterVertically) {
                    Box(
                        Modifier.width(116.dp).height(150.dp).clip(RoundedCornerShape(18.dp))
                            .background(accent)
                    ) {
                        Column(Modifier.align(Alignment.Center).padding(10.dp), horizontalAlignment=Alignment.CenterHorizontally) {
                            Text("ZAPCHICKA", color=Color.Black, fontWeight=FontWeight.Black, fontStyle=FontStyle.Italic, fontSize=16.sp)
                            Spacer(Modifier.height(8.dp))
                            Text(p.flavor.uppercase(), color=Color.Black, fontWeight=FontWeight.Bold, fontSize=11.sp)
                            Spacer(Modifier.height(10.dp))
                            Text("${p.packGrams ?: 50} g", color=Color.Black, fontSize=11.sp)
                        }
                    }
                    Spacer(Modifier.width(16.dp))
                    Column(Modifier.weight(1f)) {
                        Text(p.name, fontWeight=FontWeight.Bold, fontSize=18.sp)
                        Text("Working concept", color=accent, fontWeight=FontWeight.SemiBold, fontSize=12.sp)
                        Text("Stage: ${p.stage ?: "not recorded"}", color=ZcMuted, fontSize=12.sp)
                        Spacer(Modifier.height(8.dp))
                        Text(p.notes ?: "No notes recorded.", color=ZcMuted, fontSize=12.sp, maxLines=5, overflow=TextOverflow.Ellipsis)
                    }
                }
            }
        }
    }
}

@Composable
private fun WorkScreen(
    tasks: List<TaskEntity>,
    add: (String,String?,String)->Unit,
    setDone: (TaskEntity,Boolean)->Unit
) {
    var adding by remember { mutableStateOf(false) }
    Column(Modifier.fillMaxSize()) {
        TopIdentity("Work", "Today, follow-ups and decisions")
        Row(Modifier.fillMaxWidth().padding(horizontal=16.dp), horizontalArrangement=Arrangement.End) {
            Button(onClick={adding=true}, colors=ButtonDefaults.buttonColors(containerColor=ZcNeon, contentColor=Color.Black)) {
                Icon(Icons.Default.AddTask, null); Spacer(Modifier.width(6.dp)); Text("Add task")
            }
        }
        if (tasks.isEmpty()) {
            Box(Modifier.fillMaxSize(), contentAlignment=Alignment.Center) { Text("No work items recorded.", color=ZcMuted) }
        } else {
            LazyColumn(contentPadding=PaddingValues(16.dp), verticalArrangement=Arrangement.spacedBy(8.dp)) {
                items(tasks,key={it.id}) { t ->
                    Card(Modifier.fillMaxWidth(), colors=CardDefaults.cardColors(containerColor=ZcSurface)) {
                        Row(Modifier.padding(14.dp), verticalAlignment=Alignment.CenterVertically) {
                            Checkbox(
                                checked=t.status=="done",
                                enabled=!t.conflict,
                                onCheckedChange={setDone(t,it)},
                                colors=CheckboxDefaults.colors(checkedColor=ZcNeon, checkmarkColor=Color.Black)
                            )
                            Column(Modifier.weight(1f)) {
                                Text(t.title, fontWeight=FontWeight.SemiBold)
                                t.details?.let { Text(it,color=ZcMuted,fontSize=12.sp,maxLines=2,overflow=TextOverflow.Ellipsis) }
                                Row(horizontalArrangement=Arrangement.spacedBy(8.dp)) {
                                    Text(t.priority.uppercase(), color=if(t.priority=="high"||t.priority=="critical") ZcDanger else ZcMuted, fontSize=10.sp)
                                    if(t.pending) Text("PENDING SYNC",color=ZcTeal,fontSize=10.sp)
                                    if(t.conflict) Text("CONFLICT",color=ZcDanger,fontSize=10.sp)
                                }
                            }
                        }
                    }
                }
            }
        }
    }
    if (adding) TaskDialog(onDismiss={adding=false}) { title, details, priority ->
        add(title,details,priority); adding=false
    }
}

@Composable
private fun TaskDialog(onDismiss:()->Unit,onSave:(String,String?,String)->Unit) {
    var title by remember { mutableStateOf("") }
    var details by remember { mutableStateOf("") }
    var priority by remember { mutableStateOf("normal") }
    AlertDialog(
        onDismissRequest=onDismiss,
        title={Text("Add work item")},
        text={
            Column(verticalArrangement=Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(title,{title=it},label={Text("Title")},singleLine=true)
                OutlinedTextField(details,{details=it},label={Text("Details")},minLines=3)
                Row(horizontalArrangement=Arrangement.spacedBy(6.dp)) {
                    listOf("normal","high","critical").forEach {
                        FilterChip(selected=priority==it,onClick={priority=it},label={Text(it.replaceFirstChar(Char::uppercase))})
                    }
                }
            }
        },
        confirmButton={TextButton(enabled=title.isNotBlank(),onClick={onSave(title,details.ifBlank{null},priority)}){Text("Save")}},
        dismissButton={TextButton(onClick=onDismiss){Text("Cancel")}}
    )
}

@Composable
private fun MoreScreen(
    activity: List<ActivityEventEntity>,
    conflicts: List<LocalConflictEntity>,
    pending: Int,
    role: String,
    keepServer:(LocalConflictEntity)->Unit,
    retryMine:(LocalConflictEntity)->Unit,
    signOut:()->Unit
) {
    LazyColumn(Modifier.fillMaxSize(), contentPadding=PaddingValues(bottom=20.dp)) {
        item { TopIdentity("More", "Security, activity and sync") }
        item {
            InfoCard("Role: ${role.uppercase()} · Pending sync: $pending", Icons.Default.Security, ZcTeal)
        }
        if (conflicts.isNotEmpty()) {
            item { SectionTitle("Resolve conflicts") }
            items(conflicts,key={it.id}) { c ->
                Card(Modifier.padding(horizontal=16.dp, vertical=6.dp).fillMaxWidth(), colors=CardDefaults.cardColors(containerColor=ZcSurface)) {
                    Column(Modifier.padding(16.dp)) {
                        Text("${c.entityType.removeSuffix("s")} edit conflict", fontWeight=FontWeight.Bold)
                        Text("Nothing was silently overwritten. Choose which state should win.",color=ZcMuted,fontSize=12.sp)
                        Spacer(Modifier.height(10.dp))
                        Row(horizontalArrangement=Arrangement.spacedBy(8.dp)) {
                            OutlinedButton(onClick={keepServer(c)}) { Text("Keep server") }
                            Button(onClick={retryMine(c)},colors=ButtonDefaults.buttonColors(containerColor=ZcNeon,contentColor=Color.Black)) { Text("Retry mine") }
                        }
                    }
                }
            }
        }
        item { SectionTitle("Recent important activity") }
        if(activity.isEmpty()) item { EmptyCard("No synced activity yet.") }
        items(activity.take(20), key={it.id}) { a ->
            Row(Modifier.fillMaxWidth().padding(horizontal=20.dp, vertical=7.dp)) {
                Icon(Icons.Default.History, null, tint=ZcMuted, modifier=Modifier.size(18.dp))
                Spacer(Modifier.width(10.dp))
                Column {
                    Text("${a.action.replaceFirstChar(Char::uppercase)} · ${a.entityType}", fontSize=13.sp)
                    Text(a.occurredAt.replace("T"," ").take(19),color=ZcMuted,fontSize=11.sp)
                }
            }
        }
        item {
            Spacer(Modifier.height(18.dp))
            OutlinedButton(
                onClick=signOut,
                modifier=Modifier.padding(horizontal=16.dp).fillMaxWidth()
            ) { Icon(Icons.Default.Logout,null); Spacer(Modifier.width(8.dp)); Text("Sign out") }
        }
    }
}

@Composable
private fun AuthScreen(
    message:String?, busy:Boolean,
    signIn:(String,String)->Unit,
    signUp:(String,String,String)->Unit
) {
    var mode by remember { mutableStateOf("signin") }
    var name by remember { mutableStateOf("") }
    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0xFF071013),ZcBg)))) {
        Column(
            Modifier.align(Alignment.Center).padding(28.dp).fillMaxWidth(),
            horizontalAlignment=Alignment.CenterHorizontally
        ) {
            Box(Modifier.size(84.dp).clip(RoundedCornerShape(26.dp)).background(Color.Black).border(1.dp,ZcNeon,RoundedCornerShape(26.dp)),contentAlignment=Alignment.Center) {
                Text("ZC", color=ZcNeon,fontWeight=FontWeight.Black,fontStyle=FontStyle.Italic,fontSize=32.sp)
            }
            Spacer(Modifier.height(18.dp))
            Text("ZapChicka",fontWeight=FontWeight.Black,fontSize=30.sp)
            Text("Private business command system",color=ZcMuted,fontSize=12.sp)
            Spacer(Modifier.height(28.dp))
            if(mode=="signup") OutlinedTextField(name,{name=it},label={Text("Name")},singleLine=true,modifier=Modifier.fillMaxWidth())
            Spacer(Modifier.height(8.dp))
            OutlinedTextField(email,{email=it},label={Text("Email")},singleLine=true,modifier=Modifier.fillMaxWidth())
            Spacer(Modifier.height(8.dp))
            OutlinedTextField(
                password,{password=it},label={Text("Password")},singleLine=true,
                visualTransformation=PasswordVisualTransformation(),modifier=Modifier.fillMaxWidth()
            )
            message?.let { Text(it,color=if(it.contains("failed",true)) ZcDanger else ZcMuted,fontSize=12.sp,modifier=Modifier.padding(top=10.dp)) }
            Spacer(Modifier.height(14.dp))
            Button(
                enabled=!busy && email.isNotBlank() && password.length>=6 && (mode=="signin" || name.isNotBlank()),
                onClick={if(mode=="signin") signIn(email,password) else signUp(name,email,password)},
                modifier=Modifier.fillMaxWidth(),
                colors=ButtonDefaults.buttonColors(containerColor=ZcNeon,contentColor=Color.Black)
            ) {
                if(busy) CircularProgressIndicator(Modifier.size(18.dp),strokeWidth=2.dp,color=Color.Black)
                else Text(if(mode=="signin") "Sign in" else "Create account",fontWeight=FontWeight.Bold)
            }
            TextButton(onClick={mode=if(mode=="signin") "signup" else "signin"}) {
                Text(if(mode=="signin") "Create account" else "Already have an account?",color=ZcTeal)
            }
        }
    }
}

@Composable
private fun InviteScreen(message:String?, busy:Boolean, accept:(String)->Unit, signOut:()->Unit) {
    var code by remember { mutableStateOf("") }
    Column(
        Modifier.fillMaxSize().padding(28.dp),
        verticalArrangement=Arrangement.Center
    ) {
        Text("Connect your workspace",fontWeight=FontWeight.Black,fontSize=30.sp)
        Text("Your account is valid, but it has no ZapChicka workspace membership yet.",color=ZcMuted)
        Spacer(Modifier.height(20.dp))
        OutlinedTextField(
            code,{code=it},label={Text("Private invite code")},singleLine=true,
            visualTransformation=PasswordVisualTransformation(),modifier=Modifier.fillMaxWidth()
        )
        message?.let { Text(it,color=ZcMuted,fontSize=12.sp,modifier=Modifier.padding(top=8.dp)) }
        Spacer(Modifier.height(12.dp))
        Button(
            enabled=!busy && code.length>20,
            onClick={accept(code)},
            modifier=Modifier.fillMaxWidth(),
            colors=ButtonDefaults.buttonColors(containerColor=ZcNeon,contentColor=Color.Black)
        ) { Text("Connect",fontWeight=FontWeight.Bold) }
        TextButton(onClick=signOut,modifier=Modifier.align(Alignment.CenterHorizontally)){Text("Sign out")}
    }
}

@Composable
private fun SectionTitle(text:String) {
    Text(text,fontWeight=FontWeight.Bold,fontSize=17.sp,modifier=Modifier.padding(horizontal=20.dp,vertical=12.dp))
}

@Composable
private fun EmptyCard(text:String) {
    Card(Modifier.padding(horizontal=16.dp,vertical=6.dp).fillMaxWidth(),colors=CardDefaults.cardColors(containerColor=ZcSurface)) {
        Text(text,color=ZcMuted,modifier=Modifier.padding(18.dp))
    }
}

@Composable
private fun InfoCard(text:String, icon:androidx.compose.ui.graphics.vector.ImageVector, accent:Color) {
    Card(Modifier.padding(horizontal=16.dp,vertical=6.dp).fillMaxWidth(),colors=CardDefaults.cardColors(containerColor=ZcSurface)) {
        Row(Modifier.padding(16.dp),verticalAlignment=Alignment.CenterVertically) {
            Icon(icon,null,tint=accent)
            Spacer(Modifier.width(12.dp))
            Text(text,Modifier.weight(1f),fontSize=13.sp)
        }
    }
}

@Composable
private fun TaskMini(task:TaskEntity) {
    Card(Modifier.padding(horizontal=16.dp,vertical=4.dp).fillMaxWidth(),colors=CardDefaults.cardColors(containerColor=ZcSurface)) {
        Row(Modifier.padding(14.dp),verticalAlignment=Alignment.CenterVertically) {
            Icon(Icons.Default.CheckCircleOutline,null,tint=if(task.priority=="critical"||task.priority=="high") ZcDanger else ZcNeon)
            Spacer(Modifier.width(10.dp))
            Column {
                Text(task.title,fontWeight=FontWeight.SemiBold)
                task.details?.let { Text(it,color=ZcMuted,fontSize=11.sp,maxLines=1,overflow=TextOverflow.Ellipsis) }
            }
        }
    }
}
