package com.zapchicka.app.network

import com.zapchicka.app.security.Session
import okhttp3.*
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.net.URLEncoder
import java.nio.charset.StandardCharsets
import java.time.Instant

data class AuthResult(
    val session: Session?,
    val requiresEmailConfirmation: Boolean = false,
    val message: String? = null
)

data class WorkspaceContext(
    val workspaceId: String,
    val role: String,
    val homeMode: String
)

data class ApiResponse(val code: Int, val body: String) {
    val isSuccessful: Boolean get() = code in 200..299
}

class SupabaseApi(
    private val baseUrl: String,
    private val publishableKey: String,
    private val client: OkHttpClient = OkHttpClient()
) {
    private val jsonType = "application/json; charset=utf-8".toMediaType()

    init {
        val expectedBaseUrl = "https://zwicnihksupsfoogtvtv.supabase.co"
        require(baseUrl == expectedBaseUrl) {
            "ZapChicka safety stop: backend URL does not match the dedicated ZapChicka project."
        }
        require(publishableKey.isNotBlank()) { "SUPABASE_PUBLISHABLE_KEY is missing." }
    }

    private fun encode(value: String): String =
        URLEncoder.encode(value, StandardCharsets.UTF_8.toString())

    private fun request(
        method: String,
        path: String,
        accessToken: String? = null,
        jsonBody: String? = null,
        preferReturn: Boolean = false,
        extraHeaders: Map<String, String> = emptyMap()
    ): ApiResponse {
        val url = "$baseUrl$path"
        val builder = Request.Builder()
            .url(url)
            .header("apikey", publishableKey)
            .header("Accept", "application/json")

        if (accessToken != null) builder.header("Authorization", "Bearer $accessToken")
        if (preferReturn) builder.header("Prefer", "return=representation")
        extraHeaders.forEach { (k,v) -> builder.header(k,v) }

        val body = jsonBody?.toRequestBody(jsonType)
        when (method) {
            "GET" -> builder.get()
            "POST" -> builder.post(body ?: "{}".toRequestBody(jsonType))
            "PATCH" -> builder.patch(body ?: "{}".toRequestBody(jsonType))
            else -> error("Unsupported HTTP method: $method")
        }

        client.newCall(builder.build()).execute().use { response ->
            return ApiResponse(response.code, response.body?.string().orEmpty())
        }
    }

    fun signIn(email: String, password: String): AuthResult {
        val payload = JSONObject().put("email", email).put("password", password)
        val r = request("POST", "/auth/v1/token?grant_type=password", jsonBody = payload.toString())
        if (!r.isSuccessful) return AuthResult(null, message = errorText(r.body, "Sign in failed"))
        return AuthResult(parseSession(r.body, email))
    }

    fun signUp(email: String, password: String, displayName: String): AuthResult {
        val payload = JSONObject()
            .put("email", email)
            .put("password", password)
            .put("data", JSONObject().put("display_name", displayName))
        val r = request("POST", "/auth/v1/signup", jsonBody = payload.toString())
        if (!r.isSuccessful) return AuthResult(null, message = errorText(r.body, "Sign up failed"))

        val obj = JSONObject(r.body)
        val token = obj.optString("access_token")
        if (token.isBlank()) {
            return AuthResult(
                session = null,
                requiresEmailConfirmation = true,
                message = "Account created. Confirm the email, then sign in."
            )
        }
        return AuthResult(parseSession(r.body, email))
    }

    fun refresh(refreshToken: String, knownEmail: String?): Session? {
        val payload = JSONObject().put("refresh_token", refreshToken)
        val r = request("POST", "/auth/v1/token?grant_type=refresh_token", jsonBody = payload.toString())
        if (!r.isSuccessful) return null
        return parseSession(r.body, knownEmail)
    }

    private fun parseSession(body: String, emailFallback: String?): Session {
        val o = JSONObject(body)
        val access = o.getString("access_token")
        val refresh = o.getString("refresh_token")
        val expiresIn = o.optLong("expires_in", 3600)
        val user = o.getJSONObject("user")
        return Session(
            accessToken = access,
            refreshToken = refresh,
            expiresAtEpochSec = Instant.now().epochSecond + expiresIn,
            userId = user.getString("id"),
            email = user.optString("email").takeIf { it.isNotBlank() } ?: emailFallback
        )
    }

    fun acceptInvite(accessToken: String, token: String): WorkspaceContext {
        val payload = JSONObject().put("p_token", token)
        val r = request(
            method = "POST",
            path = "/rest/v1/rpc/accept_workspace_invite",
            accessToken = accessToken,
            jsonBody = payload.toString()
        )
        if (!r.isSuccessful) throw IOException(errorText(r.body, "Invite could not be accepted"))
        val a = JSONArray(r.body)
        if (a.length() == 0) throw IOException("Invite returned no workspace.")
        val o = a.getJSONObject(0)
        return WorkspaceContext(
            workspaceId = o.getString("workspace_id"),
            role = o.getString("role"),
            homeMode = o.getString("home_mode")
        )
    }

    fun getWorkspace(accessToken: String, userId: String): WorkspaceContext? {
        val path = "/rest/v1/workspace_members" +
            "?user_id=eq.${encode(userId)}&active=eq.true" +
            "&select=workspace_id,role,home_mode&limit=1"
        val r = request("GET", path, accessToken)
        if (!r.isSuccessful) throw IOException(errorText(r.body, "Workspace lookup failed"))
        val a = JSONArray(r.body)
        if (a.length() == 0) return null
        val o = a.getJSONObject(0)
        return WorkspaceContext(
            o.getString("workspace_id"),
            o.getString("role"),
            o.getString("home_mode")
        )
    }

    fun list(accessToken: String, table: String, workspaceId: String, order: String? = null): JSONArray {
        val orderPart = if (order != null) "&order=${encode(order)}" else ""
        val path = "/rest/v1/$table?workspace_id=eq.${encode(workspaceId)}&select=*$orderPart"
        val r = request("GET", path, accessToken)
        if (!r.isSuccessful) throw IOException(errorText(r.body, "Failed to load $table"))
        return JSONArray(r.body)
    }

    fun getById(accessToken: String, table: String, id: String): JSONObject? {
        val path = "/rest/v1/$table?id=eq.${encode(id)}&select=*&limit=1"
        val r = request("GET", path, accessToken)
        if (!r.isSuccessful) throw IOException(errorText(r.body, "Failed to load $table record"))
        val a = JSONArray(r.body)
        return if (a.length() == 0) null else a.getJSONObject(0)
    }

    fun listOpenConflicts(accessToken: String, workspaceId: String): JSONArray {
        val path = "/rest/v1/sync_conflicts" +
            "?workspace_id=eq.${encode(workspaceId)}&resolved_at=is.null" +
            "&select=*&order=raised_at.desc"
        val r = request("GET", path, accessToken)
        if (!r.isSuccessful) throw IOException(errorText(r.body, "Failed to load conflicts"))
        return JSONArray(r.body)
    }

    fun insert(accessToken: String, table: String, payload: JSONObject): ApiResponse =
        request(
            "POST",
            "/rest/v1/$table",
            accessToken,
            payload.toString(),
            preferReturn = true
        )

    fun updateVersioned(
        accessToken: String,
        table: String,
        id: String,
        baseVersion: Long,
        payload: JSONObject
    ): ApiResponse =
        request(
            "PATCH",
            "/rest/v1/$table?id=eq.${encode(id)}&version=eq.$baseVersion",
            accessToken,
            payload.toString(),
            preferReturn = true
        )

    fun createConflict(accessToken: String, payload: JSONObject): JSONObject? {
        val r = insert(accessToken, "sync_conflicts", payload)
        if (!r.isSuccessful) return null
        val a = JSONArray(r.body)
        return if (a.length() == 0) null else a.getJSONObject(0)
    }

    fun resolveConflict(accessToken: String, id: String, payload: JSONObject): Boolean {
        val r = request(
            "PATCH",
            "/rest/v1/sync_conflicts?id=eq.${encode(id)}",
            accessToken,
            payload.toString(),
            preferReturn = true
        )
        return r.isSuccessful
    }

    private fun errorText(body: String, fallback: String): String = try {
        val o = JSONObject(body)
        o.optString("msg")
            .ifBlank { o.optString("message") }
            .ifBlank { o.optString("error_description") }
            .ifBlank { o.optString("error") }
            .ifBlank { fallback }
    } catch (_: Throwable) {
        fallback
    }
}
