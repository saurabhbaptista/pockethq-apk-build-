package com.zapchicka.app.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "suppliers")
data class SupplierEntity(
    @PrimaryKey val id: String,
    val workspaceId: String,
    val name: String,
    val city: String?,
    val country: String?,
    val category: String?,
    val stage: String?,
    val notes: String?,
    val nextFollowUpAt: String?,
    val version: Long,
    val lastMutationId: String,
    val updatedAt: String?,
    val deletedAt: String?,
    val pending: Boolean = false,
    val conflict: Boolean = false
)

@Entity(tableName = "products")
data class ProductEntity(
    @PrimaryKey val id: String,
    val workspaceId: String,
    val code: String,
    val name: String,
    val flavor: String,
    val packGrams: Int?,
    val stage: String?,
    val targetRetailAed: Double?,
    val notes: String?,
    val version: Long,
    val lastMutationId: String,
    val updatedAt: String?,
    val deletedAt: String?
)

@Entity(tableName = "tasks")
data class TaskEntity(
    @PrimaryKey val id: String,
    val workspaceId: String,
    val title: String,
    val details: String?,
    val status: String,
    val priority: String,
    val dueAt: String?,
    val assignedTo: String?,
    val supplierId: String?,
    val productId: String?,
    val completedAt: String?,
    val version: Long,
    val lastMutationId: String,
    val updatedAt: String?,
    val deletedAt: String?,
    val pending: Boolean = false,
    val conflict: Boolean = false
)

@Entity(tableName = "activity_events")
data class ActivityEventEntity(
    @PrimaryKey val id: Long,
    val workspaceId: String,
    val entityType: String,
    val entityId: String?,
    val action: String,
    val actorId: String?,
    val occurredAt: String,
    val oldVersion: Long?,
    val newVersion: Long?,
    val mutationId: String?
)

@Entity(tableName = "pending_mutations")
data class PendingMutationEntity(
    @PrimaryKey val id: String,
    val workspaceId: String,
    val entityType: String,
    val entityId: String,
    val operation: String,
    val baseVersion: Long?,
    val payloadJson: String,
    val createdAtEpochMs: Long,
    val attemptCount: Int = 0,
    val lastError: String? = null
)

@Entity(tableName = "sync_conflicts")
data class LocalConflictEntity(
    @PrimaryKey val id: String,
    val serverConflictId: String?,
    val workspaceId: String,
    val entityType: String,
    val entityId: String,
    val baseVersion: Long,
    val serverVersion: Long,
    val localPayloadJson: String,
    val serverPayloadJson: String,
    val createdAtEpochMs: Long
)

@Entity(tableName = "sync_meta")
data class SyncMetaEntity(
    @PrimaryKey val key: String,
    val value: String
)
