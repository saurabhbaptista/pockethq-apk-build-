package com.zapchicka.app.sync

enum class UpdateOutcome {
    ACCEPTED,
    IDEMPOTENT_RETRY,
    CONFLICT
}

object SyncDecision {
    fun classifyUpdate(
        returnedRowCount: Int,
        mutationId: String,
        serverLastMutationId: String?
    ): UpdateOutcome = when {
        returnedRowCount > 0 -> UpdateOutcome.ACCEPTED
        mutationId == serverLastMutationId -> UpdateOutcome.IDEMPOTENT_RETRY
        else -> UpdateOutcome.CONFLICT
    }
}
