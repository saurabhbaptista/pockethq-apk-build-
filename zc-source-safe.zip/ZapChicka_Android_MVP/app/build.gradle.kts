import java.util.Properties

plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
    id("com.google.devtools.ksp")
}

val localProperties = Properties().apply {
    val f = rootProject.file("local.properties")
    if (f.exists()) f.inputStream().use(::load)
}

val signingProperties = Properties().apply {
    val f = rootProject.file("signing.properties")
    if (f.exists()) f.inputStream().use(::load)
}

fun q(value: String) = "\"${value.replace("\\", "\\\\").replace("\"", "\\\"")}\""

val expectedZapChickaProjectRef = "zwicnihksupsfoogtvtv"
val configuredSupabaseUrl = localProperties.getProperty("SUPABASE_URL", "")
if (configuredSupabaseUrl.isNotBlank()) {
    require(configuredSupabaseUrl == "https://$expectedZapChickaProjectRef.supabase.co") {
        "Refusing to build: SUPABASE_URL is not the dedicated ZapChicka Supabase project."
    }
}

kotlin {
    compilerOptions {
        jvmTarget = org.jetbrains.kotlin.gradle.dsl.JvmTarget.JVM_17
    }
}

android {
    namespace = "com.zapchicka.app"
    compileSdk = 36

    defaultConfig {
        applicationId = "com.zapchicka.app"
        minSdk = 26
        targetSdk = 36
        versionCode = 1
        versionName = "0.1.0-sync-spine"

        buildConfigField("String", "SUPABASE_URL", q(localProperties.getProperty("SUPABASE_URL", "")))
        buildConfigField("String", "SUPABASE_PUBLISHABLE_KEY", q(localProperties.getProperty("SUPABASE_PUBLISHABLE_KEY", "")))
    }

    buildFeatures {
        compose = true
        buildConfig = true
    }

    signingConfigs {
        if (signingProperties.isNotEmpty()) {
            create("release") {
                storeFile = rootProject.file(signingProperties.getProperty("storeFile"))
                storePassword = signingProperties.getProperty("storePassword")
                keyAlias = signingProperties.getProperty("keyAlias")
                keyPassword = signingProperties.getProperty("keyPassword")
            }
        }
    }

    buildTypes {
        getByName("release") {
            isMinifyEnabled = false
            signingConfig = signingConfigs.findByName("release")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    packaging {
        resources.excludes += "/META-INF/{AL2.0,LGPL2.1}"
    }

    ksp {
        arg("room.schemaLocation", "$projectDir/schemas")
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.17.0")
    implementation("androidx.activity:activity-compose:1.12.4")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.10.0")
    implementation("androidx.lifecycle:lifecycle-viewmodel-compose:2.10.0")
    implementation("androidx.lifecycle:lifecycle-runtime-compose:2.10.0")
    implementation("androidx.compose.ui:ui:1.10.0")
    implementation("androidx.compose.ui:ui-tooling-preview:1.10.0")
    implementation("androidx.compose.foundation:foundation:1.10.0")
    implementation("androidx.compose.material3:material3:1.4.0")
    implementation("androidx.compose.material:material-icons-extended:1.7.8")

    implementation("androidx.room:room-runtime:2.8.5")
    implementation("androidx.room:room-ktx:2.8.5")
    ksp("androidx.room:room-compiler:2.8.5")

    implementation("androidx.work:work-runtime-ktx:2.12.0")
    implementation("com.squareup.okhttp3:okhttp:4.12.0")

    testImplementation("junit:junit:4.13.2")
    testImplementation("androidx.room:room-testing:2.8.5")
    debugImplementation("androidx.compose.ui:ui-tooling:1.10.0")
}
